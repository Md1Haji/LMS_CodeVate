import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { BarChart, DonutChart } from "../../components/charts/SimpleCharts.jsx";
import api from "../../services/api";

const KPI_ICONS = {
  people: (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" />
    </svg>
  ),
  book: (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
    </svg>
  ),
  bolt: (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
    </svg>
  ),
};

function Kpi({ label, value, icon, tint }) {
  return (
    <div className="card" style={{ display: "flex", alignItems: "center", gap: 14 }}>
      <div
        style={{
          width: 40,
          height: 40,
          borderRadius: "var(--radius-sm)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexShrink: 0,
          background: tint.soft,
          color: tint.strong,
        }}
      >
        {icon}
      </div>
      <div>
        <div style={{ fontSize: 22, fontWeight: 800, fontFamily: "var(--font-display)", lineHeight: 1.1 }}>{value}</div>
        <div style={{ color: "var(--color-text-muted)", fontSize: 12.5, marginTop: 2 }}>{label}</div>
      </div>
    </div>
  );
}

// GET /admin/dashboard - platform-wide KPIs, charts, and recent signups.
// Owned by: Team member 1 (admin dashboard + auth/authorization)
export default function AdminOverview() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/admin/dashboard")
      .then(({ data }) => setStats(data))
      .catch((err) => setError(err.response?.data?.message || "Could not load dashboard stats"));
  }, []);

  if (error) return <div className="card" style={{ color: "var(--color-danger)" }}>{error}</div>;
  if (!stats) return <div>Loading…</div>;

  const roleData = [
    { label: "Students", value: stats.totalStudents, color: "var(--color-primary)" },
    { label: "Instructors", value: stats.totalInstructors, color: "var(--color-accent)" },
    { label: "Tutors", value: stats.totalTutors, color: "var(--color-warning)" },
  ];

  const courseStatusData = [
    { label: "Published", value: stats.publishedCourses, color: "var(--color-accent)" },
    { label: "Draft", value: stats.draftCourses, color: "var(--color-warning)" },
    { label: "Archived", value: stats.archivedCourses ?? Math.max(stats.totalCourses - stats.publishedCourses - stats.draftCourses, 0), color: "var(--color-text-muted)" },
  ];

  const enrollmentData = [
    { label: "Active", value: stats.activeEnrollments, color: "var(--color-primary)" },
    { label: "Completed", value: stats.completedEnrollments ?? 0, color: "var(--color-accent)" },
    { label: "Dropped", value: stats.droppedEnrollments ?? 0, color: "var(--color-danger)" },
  ];

  return (
    <div>
      <h1 style={{ fontSize: 26 }}>Overview</h1>
      <p style={{ color: "var(--color-text-muted)", marginTop: 4 }}>
        Platform-wide activity at a glance.
      </p>

      <div style={{ marginTop: 22, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 }}>
        <Kpi label="Students" value={stats.totalStudents} icon={KPI_ICONS.people} tint={{ soft: "var(--color-primary-soft)", strong: "var(--color-primary-dark)" }} />
        <Kpi label="Instructors" value={stats.totalInstructors} icon={KPI_ICONS.people} tint={{ soft: "var(--color-accent-soft)", strong: "var(--color-accent)" }} />
        <Kpi label="Tutors" value={stats.totalTutors} icon={KPI_ICONS.people} tint={{ soft: "#FBEFDD", strong: "var(--color-warning)" }} />
        <Kpi label="Total courses" value={stats.totalCourses} icon={KPI_ICONS.book} tint={{ soft: "var(--color-primary-soft)", strong: "var(--color-primary-dark)" }} />
      </div>

      <div style={{ marginTop: 24, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div className="card">
          <h2 style={{ fontSize: 15, marginBottom: 18 }}>Course pipeline</h2>
          <DonutChart data={courseStatusData} />
        </div>

        <div className="card">
          <h2 style={{ fontSize: 15, marginBottom: 18 }}>Community breakdown</h2>
          <BarChart data={roleData} />
        </div>
      </div>

      <div style={{ marginTop: 24, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div className="card">
          <h2 style={{ fontSize: 15, marginBottom: 18 }}>Enrollments ({stats.totalEnrollments} total)</h2>
          <BarChart data={enrollmentData} />
        </div>

        <div className="card" style={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ width: 34, height: 34, borderRadius: "var(--radius-sm)", background: "var(--color-accent-soft)", color: "var(--color-accent)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {KPI_ICONS.bolt}
              </div>
              <div style={{ color: "var(--color-text-muted)", fontSize: 13 }}>Estimated revenue</div>
            </div>
            <div style={{ fontSize: 32, fontWeight: 800, fontFamily: "var(--font-display)", marginTop: 12 }}>
              ${Number(stats.estimatedRevenue || 0).toLocaleString()}
            </div>
            <div style={{ color: "var(--color-text-muted)", fontSize: 12, marginTop: 6 }}>
              Sum of course price across all enrollments (all-time).
            </div>
          </div>
        </div>
      </div>

      <div className="card" style={{ marginTop: 24 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
          <h2 style={{ fontSize: 15 }}>Recent signups</h2>
          <Link to="/admin/users" style={{ fontSize: 13 }}>View all users →</Link>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 12 }}>
          {stats.recentUsers?.length === 0 && (
            <div style={{ fontSize: 13, color: "var(--color-text-muted)" }}>No signups yet.</div>
          )}
          {stats.recentUsers?.map((u) => (
            <div
              key={u._id}
              style={{
                border: "1px solid var(--color-border)",
                borderRadius: "var(--radius-sm)",
                padding: 12,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: 10,
              }}
            >
              <div style={{ minWidth: 0 }}>
                <div style={{ fontWeight: 600, fontSize: 13.5, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{u.name}</div>
                <div style={{ color: "var(--color-text-muted)", fontSize: 12, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{u.email}</div>
              </div>
              <span className="pill" style={{ flexShrink: 0 }}>{u.role}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}