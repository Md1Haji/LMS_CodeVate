import React from "react";

// Minimal, dependency-free SVG charts themed off the app's CSS variables.
// Owned by: Team member 1 (admin dashboard + auth/authorization)

/**
 * Horizontal bar chart. data: [{ label, value, color }]
 */
export function BarChart({ data, height = 34 }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      {data.map((d) => (
        <div key={d.label}>
          <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 5 }}>
            <span style={{ fontWeight: 600, color: "var(--color-text)" }}>{d.label}</span>
            <span style={{ color: "var(--color-text-muted)" }}>{d.value}</span>
          </div>
          <div style={{ background: "var(--color-surface-alt)", borderRadius: 999, height, overflow: "hidden" }}>
            <div
              style={{
                width: `${Math.max((d.value / max) * 100, d.value > 0 ? 4 : 0)}%`,
                height: "100%",
                borderRadius: 999,
                background: d.color,
                transition: "width 0.5s ease",
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

/**
 * Donut chart. data: [{ label, value, color }]
 */
export function DonutChart({ data, size = 148, stroke = 22 }) {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  let offset = 0;

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 22 }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ flexShrink: 0 }}>
        <g transform={`rotate(-90 ${size / 2} ${size / 2})`}>
          <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="var(--color-surface-alt)" strokeWidth={stroke} />
          {total === 0 ? null : (
            data.map((d) => {
              if (d.value === 0) return null;
              const dash = (d.value / total) * circumference;
              const circle = (
                <circle
                  key={d.label}
                  cx={size / 2}
                  cy={size / 2}
                  r={radius}
                  fill="none"
                  stroke={d.color}
                  strokeWidth={stroke}
                  strokeDasharray={`${dash} ${circumference - dash}`}
                  strokeDashoffset={-offset}
                  strokeLinecap="butt"
                />
              );
              offset += dash;
              return circle;
            })
          )}
        </g>
        <text
          x="50%"
          y="47%"
          textAnchor="middle"
          fontSize="22"
          fontWeight="800"
          fontFamily="var(--font-display)"
          fill="var(--color-text)"
        >
          {total}
        </text>
        <text x="50%" y="62%" textAnchor="middle" fontSize="10.5" fill="var(--color-text-muted)">
          total
        </text>
      </svg>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {data.map((d) => (
          <div key={d.label} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5 }}>
            <span style={{ width: 9, height: 9, borderRadius: 3, background: d.color, flexShrink: 0 }} />
            <span style={{ color: "var(--color-text-muted)" }}>{d.label}</span>
            <span style={{ fontWeight: 700, marginLeft: "auto", paddingLeft: 10 }}>{d.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}